type User = {
  id: number
  email: string
  password: string
}

const users: User[] = [
  {
    id: 1,
    email: "thai@gmail.com",
    password: "123456"
  },
  {
    id: 2,
    email: "admin@gmail.com",
    password: "admin123"
  }
]

export const userRepo = {
  create(data: Omit<User, "id">): User {
    const user = {
      id: Date.now(),
      ...data
    }

    users.push(user)
    return user
  },

  findByEmail(email: string): User | undefined {
    return users.find(u => u.email === email)
  }
}
