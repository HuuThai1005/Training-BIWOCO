console.log(">>> USER HANDLER FILE LOADED <<<")

import { Request, Response } from "express"
import { loginSchema } from "../schemas/login.schema"
import { authService } from "../services/auth.service"

export const loginHandler = async (req: Request, res: Response) => {
  const data = loginSchema.parse(req.body)
  const user = authService.login(data)

  res.json({
    success: true,
    user
  })
}
