import { Router } from "express"
import { loginHandler } from "../handlers/user.handler"
import { refreshTokenHandler } from "../handlers/token.handler"
import { authMiddleware } from "../middlewares/auth.middleware"
import { requireRole } from "../middlewares/role.middleware"
import { logoutHandler } from "../handlers/logout.handler"
const router = Router()

// auth
router.post("/login", loginHandler)
router.post("/refresh", refreshTokenHandler)
router.post("/logout", logoutHandler)
// protected
router.get("/profile", authMiddleware, (req, res) => {
  res.json({
    success: true,
    user: req.user
  })
})

// admin
router.get(
  "/admin",
  authMiddleware,
  requireRole("admin"),
  (req, res) => {
    res.json({
      success: true,
      message: "Welcome admin"
    })
  }
)


export default router
