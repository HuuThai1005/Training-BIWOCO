export const JWT_SECRET = "super-secret-key"
export const REFRESH_SECRET = "refresh-secret-key"
export interface JwtUserPayload {
  userId: number
  email: string
  role: "admin" | "member"
}
