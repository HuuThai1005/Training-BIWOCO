type User = {
  id: number
  email: string
  password: string
  role: "user" | "admin"
}

const users: User[] = [
  {
    id: 1,
    email: "thai@gmail.com",
    password: "123456",
    role: "user"
  },
  {
    id: 2,
    email: "admin@gmail.com",
    password: "admin123",
    role: "admin"
  }
  
]

export const userRepo = {
  create(data: Omit<User, "id">): User {
    const user = {
      id: Date.now(),
      ...data
    }

    users.push(user)
    return user
  },

  findByEmail(email: string): User | undefined {
    return users.find(u => u.email === email)
  }
}
