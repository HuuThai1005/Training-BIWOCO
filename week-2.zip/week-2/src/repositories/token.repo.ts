let refreshTokens: string[] = []

export const tokenRepo = {
  save(token: string) {
    refreshTokens.push(token)
  },

  exists(token: string) {
    return refreshTokens.includes(token)
  },

  remove(token: string) {
    refreshTokens = refreshTokens.filter(t => t !== token)
  }
}
