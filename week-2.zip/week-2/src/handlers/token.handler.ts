import  jwt  from "jsonwebtoken";
import { Request, Response } from "express";
import { REFRESH_SECRET, JWT_SECRET } from "../config/jwt";
import { tokenRepo } from "../repositories/token.repo";


export const refreshTokenHandler = (req: Request, res: Response) => {
    const { refreshToken} = req.body

    if (!refreshToken) {
        return res.status(401).json({message: "N refresh token"})
    }

    if (!tokenRepo.exists(refreshToken)) {
        return res.status(403).json({
            success: false,
            message: "Refresh token revoked"
        })
}


    try {
        const payload = jwt.verify(refreshToken, REFRESH_SECRET) as {
            userId: number
        }

        const newAccessToken = jwt.sign({
            userId: payload.userId
        }, JWT_SECRET, {
            expiresIn: "15m"
        })

        res.json({
            accessToken: newAccessToken
        })
    } catch {
        res.status(403).json({message: "Invalid refresh token"})
    }
}