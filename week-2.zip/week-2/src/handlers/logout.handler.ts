import { Request, Response } from "express"
import { tokenRepo } from "../repositories/token.repo"

export const logoutHandler = (req: Request, res: Response) => {
  const { refreshToken } = req.body

  if (!refreshToken) {
    return res.status(400).json({
      success: false,
      message: "Refresh token required"
    })
  }

  tokenRepo.remove(refreshToken)

  res.json({
    success: true,
    message: "Logged out"
  })
}
