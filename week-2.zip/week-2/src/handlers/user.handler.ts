import jwt from "jsonwebtoken"
import { Request, Response } from "express"
import { loginSchema } from "../schemas/login.schema"
import { authService } from "../services/auth.service"
import { JWT_SECRET, REFRESH_SECRET } from "../config/jwt"
import { success } from "zod"
import { tokenRepo } from "../repositories/token.repo"
export const loginHandler = async (req: Request, res: Response) => {
  const data = loginSchema.parse(req.body)
  const user = authService.login(data)

  const accessToken = jwt.sign(
    {
      userId: user.id,
      email: user.email,
      role: user.role
    },
    JWT_SECRET, { expiresIn: "15m" }
  
  )

  const refreshToken = jwt.sign(
    {
      userId: user.id
    },
    REFRESH_SECRET, {
      expiresIn: "7d"
    }
  )

  tokenRepo.save(refreshToken)

  res.json({
    success: true,
    accessToken,
    refreshToken
  })
}
