import { Request, Response, NextFunction } from "express";
import { ZodError } from "zod";

export const errorMiddleware = (
    err: unknown,
    req: Request,
    res: Response,
    next: NextFunction
) => { 
    if (err instanceof ZodError) {
        return res.status(400).json({
            success: false,
            message: "Valid error",
            errors: err.issues
        })
    }

    if (err instanceof Error) {
        return res.status(400).json({
            success: false,
            message: err.message
        })
    }

    return res.status(500).json({
            success: false,
            message: "Internal server error"
        })

}